# Report completeness candidate — PR #266

Candidate source: `84c67838e785644fa6dc9e13465ac09f5705385c`

This is a disposable synthetic vault. It contains the exact Task Planner build from the candidate and no sibling community plugins.

## Review steps

1. Open this folder as a vault in Obsidian 1.13.4 or 1.13.7. If prompted, trust the vault and enable community plugins.
2. Run **Task Planner: Open todo report** from the command palette.
3. Confirm the header reports **4 total**, **3 completed**, and **1 canceled**.
4. Confirm **Historical completion** appears in a dated period, **Future completion** appears under **Future completion date**, and **Future due only** plus **Missing completion** appear under **No completion date**. Each should appear once; **Still open** should not appear.
5. Search for `Future`. Confirm two tasks remain, split between **Future completion date** and **No completion date**.
6. Give feedback only on the two fallback labels and grouping semantics: are **Future completion date** and **No completion date** clear and appropriate?

The automated real-Obsidian suite already verifies all functional expectations above and confirms that the fixture note is not rewritten. No personal vault testing is needed.
